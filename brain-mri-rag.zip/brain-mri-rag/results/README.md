Generated outputs land here:

- `data_audit.md`, written by `scripts/prepare_data.py`
- `summary.md`, written by `scripts/aggregate_results.py`
