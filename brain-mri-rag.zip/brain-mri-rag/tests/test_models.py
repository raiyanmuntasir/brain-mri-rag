import sys
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("torchvision")

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from brainrag.gradcam import GradCAM  # noqa: E402
from brainrag.metrics import cam_in_brain_ratio  # noqa: E402
from brainrag.models import build_model  # noqa: E402


@pytest.mark.parametrize("name", ["hybrid", "resnet50", "efficientnet_b0", "vit_b_16"])
def test_forward_and_embed(name):
    m = build_model(name, 4, pretrained=False).eval()
    x = torch.randn(2, 3, 224, 224)
    with torch.no_grad():
        assert m(x).shape == (2, 4)
        assert m.embed(x).shape == (2, m.embed_dim)


@pytest.mark.parametrize("name", ["hybrid", "resnet50"])
def test_gradcam(name):
    import numpy as np
    m = build_model(name, 4, pretrained=False)
    cam, logits = GradCAM(m)(torch.randn(1, 3, 224, 224))
    assert cam.shape == (224, 224) and logits.shape == (1, 4)
    assert 0.0 <= cam.min() and cam.max() <= 1.0
    assert 0.0 <= cam_in_brain_ratio(cam, np.ones((224, 224), bool)) <= 1.0
