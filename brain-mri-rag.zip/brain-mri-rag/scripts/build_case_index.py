"""Embed the training images with a trained model and build the similar-case index.

Also evaluates retrieval quality: precision@k of test queries against the index.

Usage:  python scripts/build_case_index.py --model hybrid --seed 0
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from brainrag.config import ROOT, load_config  # noqa: E402
from brainrag.data import MRIDataset, eval_transform, load_split  # noqa: E402
from brainrag.metrics import precision_at_k  # noqa: E402
from brainrag.models import build_model  # noqa: E402
from brainrag.retrieval import VectorIndex  # noqa: E402


@torch.no_grad()
def embed_all(model, ds, device, bs=64):
    model.eval()
    out = []
    for x, _, _ in DataLoader(ds, bs):
        out.append(model.embed(x.to(device)).cpu().numpy())
    return np.concatenate(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="hybrid")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--config", default=str(ROOT / "configs/default.yaml"))
    args = ap.parse_args()
    cfg = load_config(args.config)
    classes, size = cfg["classes"], cfg["preprocess"]["size"]
    device = "cuda" if torch.cuda.is_available() else "cpu"

    ckpt = torch.load(cfg["paths"]["runs_dir"] / args.model / f"seed{args.seed}" / "best.pt", map_location=device)
    model = build_model(args.model, len(classes), pretrained=False)
    model.load_state_dict(ckpt["state_dict"])
    model.to(device)

    splits = cfg["paths"]["splits_csv"]
    train_ds = MRIDataset(load_split(splits, "train"), ROOT, classes, eval_transform(size))
    test_ds = MRIDataset(load_split(splits, "test"), ROOT, classes, eval_transform(size))

    emb = embed_all(model, train_ds, device)
    meta = [{"label": r.label, "processed_path": r.processed_path, "group": int(r.group)}
            for r in train_ds.df.itertuples()]
    index = VectorIndex(emb.shape[1])
    index.add(emb, meta)
    index.save(cfg["paths"]["indices_dir"] / f"cases_{args.model}")

    k = cfg["retrieval"]["k_cases"]
    q = embed_all(model, test_ds, device)
    hits = index.search(q, k)
    p_at_k = precision_at_k(test_ds.df["label"].values, [[h["label"] for h in row] for row in hits])
    # leakage check: no retrieved neighbour may belong to the query's duplicate group
    same_group = sum(h["group"] == g for row, g in zip(hits, test_ds.df["group"].values) for h in row)
    res = {"model": args.model, "seed": args.seed, "k": k, "precision_at_k": p_at_k,
           "neighbours_from_same_duplicate_group": int(same_group)}
    path = cfg["paths"]["runs_dir"] / args.model / f"seed{args.seed}" / "retrieval.json"
    path.write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
