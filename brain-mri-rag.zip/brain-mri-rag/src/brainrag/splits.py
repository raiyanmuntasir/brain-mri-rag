"""Group-aware, stratified train/val/test splitting."""
from __future__ import annotations

import numpy as np
from sklearn.model_selection import StratifiedGroupKFold


def group_split(labels, groups, test_frac: float = 0.15, val_frac: float = 0.15, seed: int = 42):
    """Return an array of 'train' | 'val' | 'test' with no group in two splits.

    Uses StratifiedGroupKFold twice: once to carve out the test set and once
    (on the remainder) to carve out validation, keeping class balance as close
    as the group structure allows.
    """
    labels = np.asarray(labels)
    groups = np.asarray(groups)
    idx = np.arange(len(labels))
    split = np.empty(len(labels), dtype=object)

    k_test = max(2, int(round(1 / test_frac)))
    sgkf = StratifiedGroupKFold(n_splits=k_test, shuffle=True, random_state=seed)
    rest, test = next(sgkf.split(idx, labels, groups))
    split[test] = "test"

    val_share = val_frac / (1 - test_frac)
    k_val = max(2, int(round(1 / val_share)))
    sgkf2 = StratifiedGroupKFold(n_splits=k_val, shuffle=True, random_state=seed + 1)
    tr, va = next(sgkf2.split(rest, labels[rest], groups[rest]))
    split[rest[tr]] = "train"
    split[rest[va]] = "val"
    return split


def assert_no_group_leakage(split, groups) -> None:
    split = np.asarray(split)
    groups = np.asarray(groups)
    for g in np.unique(groups):
        s = set(split[groups == g])
        if len(s) > 1:
            raise AssertionError(f"group {g} appears in multiple splits: {s}")
