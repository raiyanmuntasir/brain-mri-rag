"""PyTorch dataset over the preprocessed images listed in ``splits.csv``."""
from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision.transforms import v2 as T

MEAN, STD = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]


def train_transform(size: int = 224):
    return T.Compose([
        T.ToImage(), T.ToDtype(torch.float32, scale=True),
        T.RandomHorizontalFlip(),
        T.RandomAffine(degrees=10, translate=(0.05, 0.05), scale=(0.95, 1.05)),
        T.ColorJitter(brightness=0.15, contrast=0.15),
        T.Resize((size, size), antialias=True),
        T.Normalize(MEAN, STD),
    ])


def eval_transform(size: int = 224):
    return T.Compose([T.ToImage(), T.ToDtype(torch.float32, scale=True),
                      T.Resize((size, size), antialias=True), T.Normalize(MEAN, STD)])


class MRIDataset(Dataset):
    def __init__(self, table: pd.DataFrame, root: str | Path, classes: list[str], transform=None):
        self.df = table.reset_index(drop=True)
        self.root = Path(root)
        self.classes = classes
        self.cls_to_idx = {c: i for i, c in enumerate(classes)}
        self.transform = transform

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        row = self.df.iloc[i]
        img = cv2.imread(str(self.root / row["processed_path"]), cv2.IMREAD_GRAYSCALE)
        img = np.repeat(img[:, :, None], 3, axis=2)  # grayscale -> 3 channels for ImageNet backbones
        x = self.transform(img) if self.transform else torch.from_numpy(img).permute(2, 0, 1).float() / 255
        return x, self.cls_to_idx[row["label"]], i


def load_split(splits_csv: str | Path, split: str) -> pd.DataFrame:
    df = pd.read_csv(splits_csv)
    return df[df["split"] == split]
