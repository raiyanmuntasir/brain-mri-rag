"""Create README figures from your real data and runs (saved to assets/).

  assets/preprocessing.png   raw slice -> brain mask -> preprocessed, one row per class
  assets/gradcam.png         Grad-CAM overlays for test images (needs a trained model)
  assets/training_curves.png train/val loss for one run

Usage:  python scripts/make_figures.py --model hybrid --seed 0
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from brainrag.config import ROOT, load_config  # noqa: E402


def preprocessing_figure(df, classes, out):
    fig, ax = plt.subplots(len(classes), 3, figsize=(7.5, 2.5 * len(classes)))
    for r, c in enumerate(classes):
        row = df[(df.label == c) & (df.split == "test")].iloc[0]
        raw = cv2.imread(str(ROOT / row.raw_path), cv2.IMREAD_GRAYSCALE)
        for j, (img, t) in enumerate([(raw, "Raw"), (cv2.imread(str(ROOT / row.mask_path), 0), "Brain mask"),
                                      (cv2.imread(str(ROOT / row.processed_path), 0), "Preprocessed")]):
            ax[r, j].imshow(img, cmap="gray")
            ax[r, j].set_title(f"{c}: {t}" if j == 0 else t, fontsize=9)
            ax[r, j].axis("off")
    fig.tight_layout()
    fig.savefig(out, dpi=150)


def gradcam_figure(df, classes, ckpt_path, out, n=4):
    import torch
    from brainrag.data import eval_transform
    from brainrag.gradcam import GradCAM, overlay
    from brainrag.models import build_model
    ck = torch.load(ckpt_path, map_location="cpu")
    model = build_model(ck["model_name"], len(classes), pretrained=False)
    model.load_state_dict(ck["state_dict"])
    cam = GradCAM(model)
    tf = eval_transform(224)
    rows = df[df.split == "test"].groupby("label").head(1).head(n)
    fig, ax = plt.subplots(1, len(rows), figsize=(3 * len(rows), 3.2))
    for a, row in zip(np.atleast_1d(ax), rows.itertuples()):
        img = cv2.imread(str(ROOT / row.processed_path), 0)
        c, logits = cam(tf(np.repeat(img[:, :, None], 3, 2)).unsqueeze(0))
        pred = classes[int(logits.argmax())]
        a.imshow(overlay(img, c))
        a.set_title(f"true: {row.label}\npred: {pred}", fontsize=9)
        a.axis("off")
    fig.tight_layout()
    fig.savefig(out, dpi=150)


def curves_figure(hist_csv, out):
    h = pd.read_csv(hist_csv)
    fig, ax = plt.subplots(figsize=(5, 3.2))
    ax.plot(h.epoch, h.train_loss, label="train loss")
    ax.plot(h.epoch, h.val_loss, label="validation loss")
    ax.set_xlabel("epoch")
    ax.set_ylabel("loss")
    ax.legend(frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(out, dpi=150)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="hybrid")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    cfg = load_config()
    assets = ROOT / "assets"
    assets.mkdir(exist_ok=True)
    df = pd.read_csv(cfg["paths"]["splits_csv"])
    preprocessing_figure(df, cfg["classes"], assets / "preprocessing.png")
    run = cfg["paths"]["runs_dir"] / args.model / f"seed{args.seed}"
    if (run / "best.pt").exists():
        gradcam_figure(df, cfg["classes"], run / "best.pt", assets / "gradcam.png")
        curves_figure(run / "history.csv", assets / "training_curves.png")
    print(f"figures written to {assets}")


if __name__ == "__main__":
    main()
