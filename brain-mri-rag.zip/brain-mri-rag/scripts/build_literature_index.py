"""Chunk the PubMed abstracts and build the literature vector index.

Usage:  python scripts/build_literature_index.py [--tfidf]
"""
from __future__ import annotations

import argparse
import sys
from dataclasses import asdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from brainrag.config import ROOT, load_config  # noqa: E402
from brainrag.retrieval import TextEmbedder, VectorIndex, chunk_abstract, load_jsonl  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(ROOT / "configs/default.yaml"))
    ap.add_argument("--tfidf", action="store_true", help="use the TF-IDF fallback instead of PubMedBERT")
    args = ap.parse_args()
    cfg = load_config(args.config)
    records = load_jsonl(cfg["paths"]["literature_jsonl"])
    passages = [asdict(p) for r in records for p in chunk_abstract(r)]
    embedder = TextEmbedder(cfg["retrieval"]["text_model"], force_tfidf=args.tfidf)
    embedder.fit([p["text"] for p in passages])
    vecs = embedder.encode([p["text"] for p in passages])
    index = VectorIndex(vecs.shape[1])
    index.add(vecs, passages)
    index.save(cfg["paths"]["indices_dir"] / "literature")
    print(f"indexed {len(passages)} passages from {len(records)} abstracts using {embedder.backend}")


if __name__ == "__main__":
    main()
