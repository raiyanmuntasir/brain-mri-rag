"""Train one model with one seed and evaluate it on the held-out test split.

Usage:  python scripts/train.py --model hybrid --seed 0
Outputs (runs/<model>/seed<k>/): best.pt, history.csv, test_preds.npz, metrics.json
"""
from __future__ import annotations

import argparse
import json
import random
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from brainrag.config import ROOT, load_config  # noqa: E402
from brainrag.data import MRIDataset, eval_transform, load_split, train_transform  # noqa: E402
from brainrag.gradcam import GradCAM  # noqa: E402
from brainrag.metrics import bootstrap_ci, cam_in_brain_ratio, classification_metrics  # noqa: E402
from brainrag.models import build_model  # noqa: E402


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


@torch.no_grad()
def predict(model, loader, device):
    model.eval()
    probs, ys = [], []
    for x, y, _ in loader:
        probs.append(torch.softmax(model(x.to(device)), 1).cpu())
        ys.append(y)
    return torch.cat(ys).numpy(), torch.cat(probs).numpy()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--config", default=str(ROOT / "configs/default.yaml"))
    ap.add_argument("--epochs", type=int, default=None, help="override config (e.g. 1 for a smoke test)")
    args = ap.parse_args()

    cfg = load_config(args.config)
    tc = cfg["train"]
    classes = cfg["classes"]
    set_seed(args.seed)
    device = "cuda" if torch.cuda.is_available() else ("mps" if torch.backends.mps.is_available() else "cpu")
    out = cfg["paths"]["runs_dir"] / args.model / f"seed{args.seed}"
    out.mkdir(parents=True, exist_ok=True)

    splits = cfg["paths"]["splits_csv"]
    size = cfg["preprocess"]["size"]
    mk = lambda s, tf: MRIDataset(load_split(splits, s), ROOT, classes, tf)  # noqa: E731
    g = torch.Generator().manual_seed(args.seed)
    dl_train = DataLoader(mk("train", train_transform(size)), tc["batch_size"], shuffle=True,
                          num_workers=tc["num_workers"], generator=g, drop_last=True)
    dl_val = DataLoader(mk("val", eval_transform(size)), tc["batch_size"], num_workers=tc["num_workers"])
    test_ds = mk("test", eval_transform(size))
    dl_test = DataLoader(test_ds, tc["batch_size"], num_workers=tc["num_workers"])

    model = build_model(args.model, len(classes), tc["pretrained"]).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=tc["lr"], weight_decay=tc["weight_decay"])
    epochs = args.epochs or tc["epochs"]
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=tc["lr"], total_steps=epochs * len(dl_train),
                                                pct_start=0.1)
    crit = nn.CrossEntropyLoss(label_smoothing=tc["label_smoothing"])

    best_auc, bad, hist = -1.0, 0, []
    t0 = time.time()
    for ep in range(1, epochs + 1):
        model.train()
        tot, n = 0.0, 0
        for x, y, _ in dl_train:
            x, y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            loss = crit(model(x), y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            sched.step()
            tot += loss.item() * len(y)
            n += len(y)
        yv, pv = predict(model, dl_val, device)
        val_loss = float(nn.functional.nll_loss(torch.log(torch.tensor(pv) + 1e-8), torch.tensor(yv)))
        vm = classification_metrics(yv, pv, classes)
        hist.append({"epoch": ep, "train_loss": tot / n, "val_loss": val_loss,
                     "val_acc": vm["accuracy"], "val_auc": vm["macro_auc"]})
        print(f"[{args.model} s{args.seed}] ep{ep:02d} train_loss={tot / n:.4f} "
              f"val_loss={val_loss:.4f} val_acc={vm['accuracy']:.4f} val_auc={vm['macro_auc']:.4f}")
        if vm["macro_auc"] > best_auc:
            best_auc, bad = vm["macro_auc"], 0
            torch.save({"model_name": args.model, "state_dict": model.state_dict(), "classes": classes,
                        "epoch": ep, "val_auc": best_auc}, out / "best.pt")
        else:
            bad += 1
            if bad >= tc["early_stopping_patience"]:
                print("early stopping")
                break
    pd.DataFrame(hist).to_csv(out / "history.csv", index=False)

    # ---- test evaluation with the best checkpoint ------------------
    ckpt = torch.load(out / "best.pt", map_location=device)
    model.load_state_dict(ckpt["state_dict"])
    yt, pt = predict(model, dl_test, device)
    np.savez(out / "test_preds.npz", y=yt, probs=pt)
    m = classification_metrics(yt, pt, classes)
    m["macro_auc_95ci"] = bootstrap_ci(yt, pt, "macro_auc", n=1000, seed=args.seed)
    m.update({"model": args.model, "seed": args.seed, "best_epoch": ckpt["epoch"],
              "val_macro_auc": best_auc, "train_minutes": (time.time() - t0) / 60,
              "n_params_m": sum(p.numel() for p in model.parameters()) / 1e6})

    # Grad-CAM sanity check: how much attention lands inside the brain?
    if model.cam_layer is not None:
        cam = GradCAM(model)
        ratios = []
        n_cam = min(len(test_ds), 300)
        for i in np.random.default_rng(args.seed).choice(len(test_ds), n_cam, replace=False):
            x, _, _ = test_ds[int(i)]
            c, _ = cam(x.unsqueeze(0).to(device))
            mask = cv2.imread(str(ROOT / test_ds.df.iloc[int(i)]["mask_path"]), cv2.IMREAD_GRAYSCALE) > 0
            mask = cv2.resize(mask.astype(np.uint8), c.shape[::-1], interpolation=cv2.INTER_NEAREST) > 0
            ratios.append(cam_in_brain_ratio(c, mask))
        cam.remove()
        m["cam_in_brain_ratio"] = float(np.nanmean(ratios))

    (out / "metrics.json").write_text(json.dumps(m, indent=2))
    print(json.dumps({k: v for k, v in m.items() if k != "confusion_matrix"}, indent=2))


if __name__ == "__main__":
    main()
