"""brainrag: explainable, retrieval-augmented brain MRI tumour classification (research prototype)."""
__version__ = "0.1.0"

CLASSES = ["glioma", "meningioma", "notumor", "pituitary"]
