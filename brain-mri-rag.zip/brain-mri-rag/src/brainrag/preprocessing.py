"""MRI slice preprocessing: brain masking, bias correction, contrast enhancement.

The original study fed raw Kaggle JPEGs to the network, and Grad-CAM showed the
model attending to the orbits and nasal cavity. This module removes non-brain
tissue *before* training so the classifier cannot learn those shortcuts.

All functions operate on 2-D grayscale ``numpy`` arrays and have no deep-learning
dependencies, so they are fast to unit-test.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np
from scipy import ndimage as ndi


@dataclass
class PreprocessConfig:
    size: int = 224                 # output side length (square)
    mask_erode_px: int = 3          # erosion after masking, removes thin skull rim
    clahe_clip: float = 2.0         # CLAHE clip limit
    clahe_grid: int = 8             # CLAHE tile grid
    n4_bias_correction: bool = False  # requires SimpleITK
    crop_margin: float = 0.05       # margin around brain bounding box (fraction)


def load_gray(path: str | Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Could not read image: {path}")
    return img


def to_uint8(img: np.ndarray) -> np.ndarray:
    img = img.astype(np.float32)
    lo, hi = float(img.min()), float(img.max())
    if hi - lo < 1e-6:
        return np.zeros_like(img, dtype=np.uint8)
    return ((img - lo) / (hi - lo) * 255.0).round().astype(np.uint8)


def brain_mask(img: np.ndarray, erode_px: int = 3) -> np.ndarray:
    """Approximate brain mask for a single axial/coronal/sagittal slice.

    Steps: Gaussian blur -> Otsu threshold -> morphological opening to cut thin
    bridges between skull/orbits and brain -> keep the largest connected
    component -> fill holes -> light erosion.

    This is a heuristic for 2-D slices. For 3-D volumes (e.g. BraTS) use a
    dedicated tool such as HD-BET or SynthStrip instead.
    """
    u8 = to_uint8(img)
    blur = cv2.GaussianBlur(u8, (5, 5), 0)
    _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    fg = th > 0

    k = max(3, int(round(min(img.shape) * 0.02)) | 1)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    opened = cv2.morphologyEx(fg.astype(np.uint8), cv2.MORPH_OPEN, kernel) > 0

    labels, n = ndi.label(opened)
    if n == 0:
        return np.ones_like(fg, dtype=bool)
    sizes = ndi.sum(opened, labels, index=np.arange(1, n + 1))
    largest = labels == (int(np.argmax(sizes)) + 1)

    mask = ndi.binary_fill_holes(largest)
    if erode_px > 0:
        mask = ndi.binary_erosion(mask, iterations=erode_px)
    if mask.sum() < 0.01 * mask.size:  # failure guard: fall back to full frame
        return np.ones_like(fg, dtype=bool)
    return mask


def n4_bias_correction(img: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """N4 bias-field correction (optional; needs SimpleITK)."""
    try:
        import SimpleITK as sitk
    except ImportError as exc:  # pragma: no cover - optional dependency
        raise ImportError("Install SimpleITK to use N4 bias correction") from exc
    image = sitk.GetImageFromArray(img.astype(np.float32))
    m = sitk.GetImageFromArray(mask.astype(np.uint8))
    corrected = sitk.N4BiasFieldCorrectionImageFilter().Execute(image, m)
    return sitk.GetArrayFromImage(corrected)


def clahe(img_u8: np.ndarray, clip: float = 2.0, grid: int = 8) -> np.ndarray:
    return cv2.createCLAHE(clipLimit=clip, tileGridSize=(grid, grid)).apply(img_u8)


def crop_to_mask(img: np.ndarray, mask: np.ndarray, margin: float = 0.05):
    ys, xs = np.where(mask)
    if len(ys) == 0:
        return img, mask
    h, w = mask.shape
    my, mx = int(h * margin), int(w * margin)
    y0, y1 = max(0, ys.min() - my), min(h, ys.max() + 1 + my)
    x0, x1 = max(0, xs.min() - mx), min(w, xs.max() + 1 + mx)
    return img[y0:y1, x0:x1], mask[y0:y1, x0:x1]


def pad_to_square(img: np.ndarray, value: int = 0) -> np.ndarray:
    h, w = img.shape[:2]
    s = max(h, w)
    out = np.full((s, s), value, dtype=img.dtype)
    y, x = (s - h) // 2, (s - w) // 2
    out[y:y + h, x:x + w] = img
    return out


def preprocess(img: np.ndarray, cfg: PreprocessConfig | None = None):
    """Full pipeline. Returns (processed uint8 image, boolean brain mask), both size x size."""
    cfg = cfg or PreprocessConfig()
    img = img.astype(np.float32)
    mask = brain_mask(img, erode_px=cfg.mask_erode_px)

    if cfg.n4_bias_correction:
        img = n4_bias_correction(img, mask)

    img = np.where(mask, img, 0.0)
    img, mask = crop_to_mask(img, mask, cfg.crop_margin)

    # normalise intensities inside the brain only (robust percentiles)
    vals = img[mask]
    if vals.size:
        lo, hi = np.percentile(vals, [0.5, 99.5])
        img = np.clip((img - lo) / max(hi - lo, 1e-6), 0, 1) * 255.0
    img = np.where(mask, img, 0).astype(np.uint8)
    img = clahe(img, cfg.clahe_clip, cfg.clahe_grid)
    img = np.where(mask, img, 0).astype(np.uint8)

    img = pad_to_square(img)
    mask = pad_to_square(mask.astype(np.uint8)).astype(bool)
    img = cv2.resize(img, (cfg.size, cfg.size), interpolation=cv2.INTER_AREA)
    mask = cv2.resize(mask.astype(np.uint8), (cfg.size, cfg.size),
                      interpolation=cv2.INTER_NEAREST).astype(bool)
    img[~mask] = 0  # keep image and mask consistent after resampling
    return img, mask
