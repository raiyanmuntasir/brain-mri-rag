"""End-to-end inference: image -> preprocessing -> classifier + Grad-CAM -> retrieval -> report."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import torch

from .config import load_config
from .data import eval_transform
from .gradcam import GradCAM, overlay
from .metrics import cam_in_brain_ratio
from .models import build_model
from .preprocessing import PreprocessConfig, preprocess
from .rag import Evidence, generate_report
from .retrieval import TextEmbedder, VectorIndex, load_jsonl


class BrainMRIAssistant:
    def __init__(self, checkpoint: str | Path, cfg_path: str | Path | None = None, device: str | None = None):
        self.cfg = load_config(cfg_path) if cfg_path else load_config()
        self.classes = self.cfg["classes"]
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        ckpt = torch.load(checkpoint, map_location=self.device)
        self.model = build_model(ckpt["model_name"], len(self.classes), pretrained=False)
        self.model.load_state_dict(ckpt["state_dict"])
        self.model.to(self.device).eval()
        self.cam = GradCAM(self.model) if self.model.cam_layer is not None else None
        self.pcfg = PreprocessConfig(**self.cfg["preprocess"])
        self.tf = eval_transform(self.pcfg.size)

        idx_dir = self.cfg["paths"]["indices_dir"]
        self.case_index = VectorIndex.load(idx_dir / f"cases_{ckpt['model_name']}")
        self.lit_index, self.embedder = None, None
        lit_path = self.cfg["paths"]["literature_jsonl"]
        if (idx_dir / "literature").exists() and Path(lit_path).exists():
            self.lit_index = VectorIndex.load(idx_dir / "literature")
            self.embedder = TextEmbedder(self.cfg["retrieval"]["text_model"])
            if self.embedder.backend == "tfidf":
                self.embedder.fit([m["text"] for m in self.lit_index.meta])

    def analyse(self, gray: np.ndarray) -> dict:
        img, mask = preprocess(gray, self.pcfg)
        x = self.tf(np.repeat(img[:, :, None], 3, axis=2)).unsqueeze(0).to(self.device)

        if self.cam is not None:
            cam, logits = self.cam(x)
            in_brain = cam_in_brain_ratio(cam, mask)
        else:
            with torch.no_grad():
                logits = self.model(x)
            cam, in_brain = None, None
        probs = torch.softmax(logits, 1)[0].cpu().numpy()

        with torch.no_grad():
            emb = self.model.embed(x).cpu().numpy()
        cases = self.case_index.search(emb, self.cfg["retrieval"]["k_cases"])[0]

        passages = []
        if self.lit_index is not None:
            pred = self.classes[int(probs.argmax())]
            query = f"{pred} brain tumour MRI imaging features diagnosis"
            q = self.embedder.encode([query])
            passages = self.lit_index.search(q, self.cfg["retrieval"]["k_passages"])[0]

        ev = Evidence(self.classes, probs.tolist(), in_brain, cases, passages)
        rep = generate_report(ev, llm=self.cfg["rag"]["llm"], model=self.cfg["rag"]["model"],
                              host=self.cfg["rag"]["host"])
        return {"processed": img, "mask": mask, "probs": dict(zip(self.classes, probs.tolist())),
                "cam": cam, "cam_overlay": overlay(img, cam) if cam is not None else None,
                "cam_in_brain": in_brain, "similar_cases": cases, "passages": passages, **rep}
