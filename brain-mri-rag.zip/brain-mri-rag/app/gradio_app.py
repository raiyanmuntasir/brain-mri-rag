"""Interactive demo.  Usage:  python app/gradio_app.py --checkpoint runs/hybrid/seed0/best.pt"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import gradio as gr
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from brainrag.config import ROOT  # noqa: E402
from brainrag.pipeline import BrainMRIAssistant  # noqa: E402


def build(assistant: BrainMRIAssistant) -> gr.Blocks:
    def run(image):
        if image is None:
            return None, None, {}, [], "Upload an image."
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY) if image.ndim == 3 else image
        r = assistant.analyse(gray)
        gallery = []
        for c in r["similar_cases"]:
            img = cv2.imread(str(ROOT / c["processed_path"]), cv2.IMREAD_GRAYSCALE)
            gallery.append((img, f"{c['label']} (sim {c['score']:.2f})"))
        cam = r["cam_overlay"] if r["cam_overlay"] is not None else np.zeros_like(r["processed"])
        return r["processed"], cam, r["probs"], gallery, r["report"]

    with gr.Blocks(title="Brain MRI RAG assistant (research prototype)") as demo:
        gr.Markdown("## Retrieval-augmented brain MRI assistant\n"
                    "**Research prototype. Not for clinical use.** Upload a 2-D brain MRI slice.")
        with gr.Row():
            inp = gr.Image(label="Input slice", type="numpy")
            proc = gr.Image(label="Preprocessed (skull-stripped, CLAHE)")
            cam = gr.Image(label="Grad-CAM")
        probs = gr.Label(label="Class probabilities", num_top_classes=4)
        gal = gr.Gallery(label="Most similar reference cases", columns=5, height=180)
        rep = gr.Textbox(label="Evidence-grounded summary", lines=16)
        gr.Button("Analyse").click(run, inp, [proc, cam, probs, gal, rep])
    return demo


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", default=str(ROOT / "runs/hybrid/seed0/best.pt"))
    ap.add_argument("--share", action="store_true")
    a = ap.parse_args()
    build(BrainMRIAssistant(a.checkpoint)).launch(share=a.share)
