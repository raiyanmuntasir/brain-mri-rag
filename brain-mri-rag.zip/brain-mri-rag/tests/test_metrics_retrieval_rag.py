import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from brainrag.metrics import (bootstrap_ci, cam_in_brain_ratio, cam_iou, cam_pointing_game,  # noqa: E402
                              classification_metrics, precision_at_k)
from brainrag.rag import Evidence, build_prompt, generate_report, template_report, validate_citations  # noqa: E402
from brainrag.retrieval import TextEmbedder, VectorIndex, chunk_abstract  # noqa: E402

CLASSES = ["glioma", "meningioma", "notumor", "pituitary"]


def test_classification_metrics_perfect():
    y = np.array([0, 1, 2, 3] * 10)
    p = np.eye(4)[y] * 0.9 + 0.025
    m = classification_metrics(y, p, CLASSES)
    assert m["accuracy"] == 1.0 and m["macro_auc"] == 1.0
    lo, hi = bootstrap_ci(y, p, n=200)
    assert lo <= 1.0 <= hi + 1e-9


def test_cam_metrics():
    cam = np.zeros((10, 10))
    cam[2:4, 2:4] = 1
    brain = np.zeros((10, 10), bool)
    brain[:5, :5] = True
    assert cam_in_brain_ratio(cam, brain) == 1.0
    assert cam_in_brain_ratio(cam, ~brain) == 0.0
    lesion = np.zeros((10, 10), bool)
    lesion[2:4, 2:4] = True
    assert cam_pointing_game(cam, lesion)
    assert cam_iou(cam, lesion, quantile=0.95) > 0.5


def test_vector_index_search_and_persistence(tmp_path):
    rng = np.random.default_rng(0)
    centres = rng.normal(size=(4, 16))
    X = np.vstack([c + 0.05 * rng.normal(size=(20, 16)) for c in centres])
    labels = np.repeat(CLASSES, 20)
    idx = VectorIndex(16, use_faiss=False)
    idx.add(X, [{"label": l} for l in labels])
    q = centres + 0.05 * rng.normal(size=centres.shape)
    hits = idx.search(q, k=5)
    assert precision_at_k(CLASSES, [[h["label"] for h in row] for row in hits]) == 1.0
    idx.save(tmp_path / "ix")
    idx2 = VectorIndex.load(tmp_path / "ix", use_faiss=False)
    assert idx2.search(q[:1], 1)[0][0]["label"] == "glioma"


def test_text_retrieval_tfidf():
    recs = [
        {"pmid": "1", "title": "Glioma imaging", "abstract": "Gliomas show infiltrative margins on MRI. "
         "Enhancement patterns vary with grade. Peritumoral edema is common."},
        {"pmid": "2", "title": "Meningioma imaging", "abstract": "Meningiomas are extra-axial dural-based tumours. "
         "A dural tail sign is frequently seen. They enhance homogeneously."},
    ]
    passages = [p for r in recs for p in chunk_abstract(r)]
    emb = TextEmbedder(force_tfidf=True).fit([p.text for p in passages])
    idx = VectorIndex(emb.encode([passages[0].text]).shape[1], use_faiss=False)
    idx.add(emb.encode([p.text for p in passages]), [{"pmid": p.pmid, "text": p.text} for p in passages])
    top = idx.search(emb.encode(["dural tail sign extra-axial"]), 1)[0][0]
    assert top["pmid"] == "2"


def _evidence(conf=0.9, cam=0.95):
    probs = [conf, (1 - conf) / 3, (1 - conf) / 3, (1 - conf) / 3]
    return Evidence(CLASSES, probs, cam,
                    [{"label": "glioma", "score": 0.93}, {"label": "glioma", "score": 0.91},
                     {"label": "meningioma", "score": 0.88}],
                    [{"text": "Gliomas show infiltrative margins.", "pmid": "1", "title": "Glioma imaging",
                      "journal": "J Neuroimaging", "year": "2021"}])


def test_prompt_contains_evidence():
    p = build_prompt(_evidence())
    assert "glioma" in p and "[1]" in p and "2/3" in p


def test_citation_validator_flags_fabricated_reference():
    good = validate_citations("Gliomas show infiltrative margins on MRI [1].", 1)
    bad = validate_citations("Gliomas show infiltrative margins on MRI [4].", 1)
    assert good["valid"] and good["citation_coverage"] == 1.0
    assert not bad["valid"] and bad["invalid_citations"] == [4]


def test_template_report_flags_uncertainty():
    t = template_report(_evidence(conf=0.4, cam=0.5))
    assert "low" in t.lower() and "outside the brain" in t


def test_generate_report_falls_back_without_llm():
    out = generate_report(_evidence(), llm="ollama", host="http://127.0.0.1:9")  # nothing listens on :9
    assert out["backend"].startswith("template")
    assert "NOT FOR CLINICAL USE" in out["report"]
    assert out["citation_check"]["valid"]
