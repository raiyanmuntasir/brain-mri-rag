"""Near-duplicate detection so that copies of the same scan never straddle splits.

The public Kaggle brain-tumour MRI collection is assembled from several older
datasets and contains exact and near-exact duplicates, some of them shared
between its own Training/ and Testing/ folders. Random splitting therefore
leaks test images into training and inflates accuracy.

We compute a 64-bit difference hash (dHash) per image, link any pair whose
Hamming distance is <= ``max_distance`` and return connected components as
duplicate *groups*. Splits are then made at the group level (see ``splits.py``).
"""
from __future__ import annotations

import cv2
import numpy as np


def dhash(img: np.ndarray, hash_size: int = 8) -> int:
    """Difference hash of a grayscale image -> python int with hash_size**2 bits."""
    small = cv2.resize(img, (hash_size + 1, hash_size), interpolation=cv2.INTER_AREA)
    diff = small[:, 1:] > small[:, :-1]
    bits = np.packbits(diff.flatten())
    return int.from_bytes(bits.tobytes(), "big")


def _popcount64(x: np.ndarray) -> np.ndarray:
    x = x.astype(np.uint64)
    x = x - ((x >> np.uint64(1)) & np.uint64(0x5555555555555555))
    x = (x & np.uint64(0x3333333333333333)) + ((x >> np.uint64(2)) & np.uint64(0x3333333333333333))
    x = (x + (x >> np.uint64(4))) & np.uint64(0x0F0F0F0F0F0F0F0F)
    return ((x * np.uint64(0x0101010101010101)) >> np.uint64(56)).astype(np.int64)


class _UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))

    def find(self, i: int) -> int:
        while self.parent[i] != i:
            self.parent[i] = self.parent[self.parent[i]]
            i = self.parent[i]
        return i

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[rb] = ra


def duplicate_groups(hashes: list[int], max_distance: int = 4) -> np.ndarray:
    """Assign a group id to every image; near-duplicates share a group id."""
    h = np.array(hashes, dtype=np.uint64)
    n = len(h)
    uf = _UnionFind(n)
    for i in range(n - 1):
        d = _popcount64(np.bitwise_xor(h[i], h[i + 1:]))
        for j in np.nonzero(d <= max_distance)[0]:
            uf.union(i, i + 1 + int(j))
    roots = np.array([uf.find(i) for i in range(n)])
    _, group_ids = np.unique(roots, return_inverse=True)
    return group_ids


def embedding_duplicate_groups(emb: np.ndarray, threshold: float = 0.98) -> np.ndarray:
    """Second-pass grouping using cosine similarity of CNN embeddings."""
    e = emb / (np.linalg.norm(emb, axis=1, keepdims=True) + 1e-12)
    n = len(e)
    uf = _UnionFind(n)
    for i in range(n - 1):
        sims = e[i + 1:] @ e[i]
        for j in np.nonzero(sims >= threshold)[0]:
            uf.union(i, i + 1 + int(j))
    roots = np.array([uf.find(i) for i in range(n)])
    _, group_ids = np.unique(roots, return_inverse=True)
    return group_ids


def label_conflicts(group_ids: np.ndarray, labels: list[str]) -> list[int]:
    """Groups whose members carry different labels (worth manual review)."""
    out = []
    labels = np.asarray(labels)
    for g in np.unique(group_ids):
        if len(set(labels[group_ids == g])) > 1:
            out.append(int(g))
    return out
