"""Hybrid CNN-ViT classifier and baselines.

Every model exposes ``forward(x) -> logits`` and ``embed(x) -> feature vector``
(the vector used for similar-case retrieval), plus ``cam_layer`` (the module
Grad-CAM hooks into).
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torchvision.models as tvm


def _weights(enum, pretrained: bool):
    return enum.DEFAULT if pretrained else None


class HybridCNNViT(nn.Module):
    """CNN branch for local texture + ViT branch for global context, fused by cross-attention.

    * CNN branch: ResNet-50 up to ``layer3`` (stride 16 -> 14x14 map for 224 input).
    * ViT branch: torchvision ViT-B/16 encoder (14x14 patch tokens + CLS).
    * Fusion: the ViT CLS token attends over the projected CNN tokens with
      multi-head cross-attention; the result is concatenated with pooled CNN and
      ViT features and passed to an MLP head.
    """

    def __init__(self, num_classes: int = 4, pretrained: bool = True, d_model: int = 768,
                 fusion_heads: int = 8, dropout: float = 0.3):
        super().__init__()
        r = tvm.resnet50(weights=_weights(tvm.ResNet50_Weights, pretrained))
        self.cnn = nn.Sequential(r.conv1, r.bn1, r.relu, r.maxpool, r.layer1, r.layer2, r.layer3)
        self.cnn_proj = nn.Conv2d(1024, d_model, kernel_size=1)

        self.vit = tvm.vit_b_16(weights=_weights(tvm.ViT_B_16_Weights, pretrained))
        self.vit.heads = nn.Identity()
        assert self.vit.hidden_dim == d_model

        self.cross_attn = nn.MultiheadAttention(d_model, fusion_heads, dropout=0.1, batch_first=True)
        self.fuse_norm = nn.LayerNorm(d_model)
        self.embed_dim = 3 * d_model
        self.head = nn.Sequential(nn.LayerNorm(self.embed_dim), nn.Dropout(dropout),
                                  nn.Linear(self.embed_dim, 512), nn.GELU(), nn.Dropout(dropout),
                                  nn.Linear(512, num_classes))

    @property
    def cam_layer(self) -> nn.Module:
        return self.cnn[-1]  # ResNet layer3

    def _vit_tokens(self, x: torch.Tensor) -> torch.Tensor:
        t = self.vit._process_input(x)
        cls = self.vit.class_token.expand(t.shape[0], -1, -1)
        return self.vit.encoder(torch.cat([cls, t], dim=1))  # (B, 1+N, D)

    def embed(self, x: torch.Tensor) -> torch.Tensor:
        fmap = self.cnn_proj(self.cnn(x))                     # (B, D, 14, 14)
        cnn_tokens = fmap.flatten(2).transpose(1, 2)          # (B, 196, D)
        cnn_pool = cnn_tokens.mean(1)
        vt = self._vit_tokens(x)
        cls = vt[:, :1]                                       # (B, 1, D)
        fused, _ = self.cross_attn(query=cls, key=cnn_tokens, value=cnn_tokens)
        fused = self.fuse_norm(fused + cls).squeeze(1)
        return torch.cat([cnn_pool, cls.squeeze(1), fused], dim=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(self.embed(x))


class _Baseline(nn.Module):
    def __init__(self, backbone: nn.Module, feat_dim: int, num_classes: int, cam_layer: nn.Module | None):
        super().__init__()
        self.backbone = backbone
        self.embed_dim = feat_dim
        self.head = nn.Sequential(nn.Dropout(0.3), nn.Linear(feat_dim, num_classes))
        self._cam_layer = cam_layer

    @property
    def cam_layer(self):
        return self._cam_layer

    def embed(self, x):
        return self.backbone(x)

    def forward(self, x):
        return self.head(self.embed(x))


def build_model(name: str, num_classes: int = 4, pretrained: bool = True) -> nn.Module:
    name = name.lower()
    if name == "hybrid":
        return HybridCNNViT(num_classes, pretrained)
    if name == "resnet50":
        m = tvm.resnet50(weights=_weights(tvm.ResNet50_Weights, pretrained))
        dim = m.fc.in_features
        m.fc = nn.Identity()
        return _Baseline(m, dim, num_classes, m.layer4)
    if name == "efficientnet_b0":
        m = tvm.efficientnet_b0(weights=_weights(tvm.EfficientNet_B0_Weights, pretrained))
        dim = m.classifier[1].in_features
        m.classifier = nn.Identity()
        return _Baseline(m, dim, num_classes, m.features[-1])
    if name == "vit_b_16":
        m = tvm.vit_b_16(weights=_weights(tvm.ViT_B_16_Weights, pretrained))
        dim = m.hidden_dim
        m.heads = nn.Identity()
        return _Baseline(m, dim, num_classes, None)  # no conv layer: Grad-CAM not applicable
    raise ValueError(f"unknown model '{name}'")


MODEL_NAMES = ["hybrid", "resnet50", "efficientnet_b0", "vit_b_16"]
