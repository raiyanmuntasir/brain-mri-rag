"""Grad-CAM for any model exposing ``cam_layer``."""
from __future__ import annotations

import cv2
import numpy as np
import torch
import torch.nn.functional as F


class GradCAM:
    def __init__(self, model: torch.nn.Module, layer: torch.nn.Module | None = None):
        self.model = model
        self.layer = layer if layer is not None else model.cam_layer
        if self.layer is None:
            raise ValueError("model has no convolutional layer for Grad-CAM")
        self._acts = None
        self._grads = None
        # A tensor hook on the layer output is more robust than a module backward
        # hook when the network uses in-place activations.
        self._h1 = self.layer.register_forward_hook(self._save_acts)

    def _save_acts(self, _m, _i, out):
        self._acts = out.detach()
        if out.requires_grad:
            out.register_hook(self._save_grads)

    def _save_grads(self, grad):
        self._grads = grad.detach()

    def remove(self):
        self._h1.remove()

    def __call__(self, x: torch.Tensor, target: int | None = None) -> tuple[np.ndarray, torch.Tensor]:
        """Return (cam HxW in [0,1] at input resolution, logits) for a single image batch of 1."""
        self.model.eval()
        x = x.requires_grad_(True)
        logits = self.model(x)
        cls = int(logits.argmax(1)) if target is None else int(target)
        self.model.zero_grad(set_to_none=True)
        logits[0, cls].backward()
        weights = self._grads.mean(dim=(2, 3), keepdim=True)
        cam = F.relu((weights * self._acts).sum(1, keepdim=True))
        cam = F.interpolate(cam, size=x.shape[-2:], mode="bilinear", align_corners=False)[0, 0]
        cam = cam.cpu().numpy()
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return cam, logits.detach()


def overlay(gray_u8: np.ndarray, cam: np.ndarray, alpha: float = 0.4) -> np.ndarray:
    """RGB overlay of a heat map on a grayscale image."""
    heat = cv2.applyColorMap((cam * 255).astype(np.uint8), cv2.COLORMAP_JET)[:, :, ::-1]
    base = np.stack([gray_u8] * 3, axis=-1)
    return (alpha * heat + (1 - alpha) * base).astype(np.uint8)
