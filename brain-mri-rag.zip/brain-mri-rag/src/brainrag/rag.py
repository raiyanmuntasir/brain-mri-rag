"""Retrieval-augmented report generation with citation checking.

The language model never sees the image. It receives only structured, verifiable
evidence: the classifier's probabilities, an explainability summary, the labels
of the most similar reference cases, and numbered literature passages. It must
cite every claim with [n] markers that map back to those passages. A validator
then checks the citations, and if no LLM is reachable, a deterministic template
report is produced instead, so the system never fails silently.
"""
from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from dataclasses import dataclass

DISCLAIMER = ("RESEARCH PROTOTYPE - NOT FOR CLINICAL USE. This output has not been validated "
              "for diagnosis and must not inform patient care.")

SYSTEM_PROMPT = """You are a research assistant summarising the output of an experimental \
brain-MRI classification model for a technical audience.
Rules:
1. Use ONLY the evidence provided. Do not add facts from memory.
2. Every sentence that states a medical or scientific fact must end with a citation like [1] \
or [2][3], referring to the numbered literature passages.
3. Report the model's prediction and its uncertainty plainly; never state or imply a diagnosis.
4. If the evidence is weak or conflicting (low confidence, mixed similar cases, low in-brain \
attention), say so explicitly.
5. Keep it under 200 words. Use the headings: Model output, Supporting evidence, Caveats."""


@dataclass
class Evidence:
    class_names: list[str]
    probs: list[float]
    cam_in_brain: float | None
    similar_cases: list[dict]     # each: {"label": str, "score": float, ...}
    passages: list[dict]          # each: {"text", "pmid", "title", "year", "journal"}

    @property
    def predicted(self) -> str:
        return self.class_names[max(range(len(self.probs)), key=self.probs.__getitem__)]

    @property
    def confidence(self) -> float:
        return max(self.probs)


def build_prompt(ev: Evidence) -> str:
    probs = ", ".join(f"{c}: {p:.3f}" for c, p in sorted(zip(ev.class_names, ev.probs), key=lambda t: -t[1]))
    cases = "\n".join(f"- case {i + 1}: label={c['label']}, similarity={c['score']:.3f}"
                      for i, c in enumerate(ev.similar_cases)) or "- none"
    agree = sum(c["label"] == ev.predicted for c in ev.similar_cases)
    lit = "\n".join(f"[{i + 1}] {p['text']} (PMID {p['pmid']}; {p.get('journal', '')} {p.get('year', '')})"
                    for i, p in enumerate(ev.passages)) or "(no passages retrieved)"
    cam = "n/a" if ev.cam_in_brain is None else f"{ev.cam_in_brain:.2f}"
    return (f"MODEL OUTPUT\nPredicted class: {ev.predicted} (probability {ev.confidence:.3f})\n"
            f"All class probabilities: {probs}\n"
            f"Fraction of Grad-CAM attention inside the brain mask: {cam}\n\n"
            f"MOST SIMILAR REFERENCE CASES ({agree}/{len(ev.similar_cases)} share the predicted label)\n{cases}\n\n"
            f"LITERATURE PASSAGES\n{lit}\n\nWrite the summary now.")


# ---------------------------------------------------------------------
# LLM back-ends
# ---------------------------------------------------------------------
def ollama_generate(prompt: str, model: str = "llama3.1:8b", host: str = "http://localhost:11434",
                    system: str = SYSTEM_PROMPT, temperature: float = 0.1, timeout: float = 120) -> str:
    """Call a locally running Ollama server. Raises ConnectionError if unreachable."""
    payload = json.dumps({"model": model, "prompt": prompt, "system": system, "stream": False,
                          "options": {"temperature": temperature}}).encode()
    req = urllib.request.Request(f"{host}/api/generate", data=payload,
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())["response"].strip()
    except (urllib.error.URLError, OSError) as exc:
        raise ConnectionError(f"Ollama not reachable at {host}: {exc}") from exc


def template_report(ev: Evidence) -> str:
    """Deterministic fallback used when no LLM is available."""
    agree = sum(c["label"] == ev.predicted for c in ev.similar_cases)
    lines = ["Model output",
             f"The classifier assigns the highest probability to '{ev.predicted}' "
             f"({ev.confidence:.1%}).",
             "",
             "Supporting evidence",
             f"{agree} of {len(ev.similar_cases)} most similar reference cases carry the same label."]
    for i, p in enumerate(ev.passages[:3]):
        lines.append(f"Related literature: \"{p['title']}\" [{i + 1}].")
    lines += ["", "Caveats"]
    if ev.confidence < 0.7:
        lines.append("Model confidence is low; treat the prediction as uncertain.")
    if ev.cam_in_brain is not None and ev.cam_in_brain < 0.8:
        lines.append("A notable share of model attention falls outside the brain; the prediction "
                     "may rely on non-anatomical cues.")
    if ev.similar_cases and agree < len(ev.similar_cases) / 2:
        lines.append("Similar reference cases are mostly labelled differently from the prediction.")
    lines.append("Automated output from a research model; not a diagnosis.")
    return "\n".join(lines)


# ---------------------------------------------------------------------
# Citation validation
# ---------------------------------------------------------------------
_CIT = re.compile(r"\[(\d+)\]")


def validate_citations(report: str, n_passages: int) -> dict:
    """Check that citations exist and point to real passages.

    Returns counts plus ``valid`` (no out-of-range citations) and
    ``citation_coverage`` (share of content sentences carrying >=1 citation).
    """
    cited = [int(m) for m in _CIT.findall(report)]
    invalid = sorted({c for c in cited if c < 1 or c > n_passages})
    body = [ln for ln in report.splitlines()
            if ln.strip() and ln.strip().rstrip(":") not in {"Model output", "Supporting evidence", "Caveats"}]
    sentences = [s for ln in body for s in re.split(r"(?<=[.!?])\s+", ln) if len(s.split()) > 3]
    with_cit = sum(bool(_CIT.search(s)) for s in sentences)
    return {
        "n_citations": len(cited),
        "unique_cited": sorted(set(cited)),
        "invalid_citations": invalid,
        "valid": not invalid,
        "citation_coverage": with_cit / len(sentences) if sentences else 0.0,
    }


def generate_report(ev: Evidence, llm: str = "ollama", model: str = "llama3.1:8b",
                    host: str = "http://localhost:11434") -> dict:
    prompt = build_prompt(ev)
    backend = "template"
    text = None
    if llm == "ollama":
        try:
            text = ollama_generate(prompt, model=model, host=host)
            backend = f"ollama:{model}"
        except ConnectionError:
            text = None
    if text is None:
        text = template_report(ev)
    check = validate_citations(text, len(ev.passages))
    if not check["valid"]:  # never show a report with fabricated references
        text = template_report(ev)
        backend += "->template(invalid citations)"
        check = validate_citations(text, len(ev.passages))
    refs = "\n".join(f"[{i + 1}] {p['title']}. {p.get('journal', '')} {p.get('year', '')}. PMID {p['pmid']}"
                     for i, p in enumerate(ev.passages))
    return {"report": f"{DISCLAIMER}\n\n{text}\n\nReferences\n{refs}", "backend": backend,
            "citation_check": check, "prompt": prompt}
