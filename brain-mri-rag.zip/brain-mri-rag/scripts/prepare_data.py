"""Preprocess images, remove near-duplicate leakage and create group-aware splits.

Usage:  python scripts/prepare_data.py [--config configs/default.yaml]

Outputs
  data/processed/<class>/<id>.png        preprocessed slice
  data/processed/<class>/<id>_mask.png   brain mask
  data/splits.csv                        one row per image with group id and split
  results/data_audit.md                  duplicate / leakage report
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
try:
    from tqdm import tqdm
except ImportError:  # progress bar is optional
    def tqdm(x, **_):
        return x

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from brainrag.config import ROOT, load_config  # noqa: E402
from brainrag.dedup import dhash, duplicate_groups, label_conflicts  # noqa: E402
from brainrag.preprocessing import PreprocessConfig, load_gray, preprocess  # noqa: E402
from brainrag.splits import assert_no_group_leakage, group_split  # noqa: E402

def rel(p: Path) -> str:
    """Path relative to the repo when possible (portable splits.csv), else absolute."""
    try:
        return str(p.relative_to(ROOT))
    except ValueError:
        return str(p)


EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(ROOT / "configs/default.yaml"))
    args = ap.parse_args()
    cfg = load_config(args.config)
    raw, out = cfg["paths"]["raw_dir"], cfg["paths"]["processed_dir"]
    classes = cfg["classes"]
    pcfg = PreprocessConfig(**cfg["preprocess"])

    files = [p for p in raw.rglob("*") if p.suffix.lower() in EXTS and p.parent.name in classes]
    if not files:
        sys.exit(f"No images found under {raw}. See data/README.md for download instructions.")

    rows = []
    for i, p in enumerate(tqdm(sorted(files), desc="preprocessing")):
        gray = load_gray(p)
        img, mask = preprocess(gray, pcfg)
        label = p.parent.name
        (out / label).mkdir(parents=True, exist_ok=True)
        stem = f"{i:05d}"
        cv2.imwrite(str(out / label / f"{stem}.png"), img)
        cv2.imwrite(str(out / label / f"{stem}_mask.png"), mask.astype(np.uint8) * 255)
        rows.append({
            "raw_path": rel(p),
            "processed_path": rel(out / label / f"{stem}.png"),
            "mask_path": rel(out / label / f"{stem}_mask.png"),
            "label": label,
            "source_split": p.parent.parent.name,          # Kaggle's own Training/Testing folder
            "hash": dhash(cv2.resize(gray, (256, 256))),   # hash the *raw* image
            "brain_fraction": float(mask.mean()),
        })
    df = pd.DataFrame(rows)

    df["group"] = duplicate_groups(df["hash"].tolist(), cfg["dedup"]["hash_max_distance"])
    conflicts = label_conflicts(df["group"].values, df["label"].tolist())
    n_conflict_imgs = int(df["group"].isin(conflicts).sum())
    df = df[~df["group"].isin(conflicts)].reset_index(drop=True)  # ambiguous labels: drop

    # How much did Kaggle's original split leak?  Testing images with a near-duplicate in Training.
    tr_groups = set(df.loc[df.source_split.str.lower().str.startswith("train"), "group"])
    te_mask = df.source_split.str.lower().str.startswith("test")
    leaked = int(df.loc[te_mask, "group"].isin(tr_groups).sum())

    df["split"] = group_split(df["label"].values, df["group"].values,
                              cfg["split"]["test_frac"], cfg["split"]["val_frac"], cfg["split"]["seed"])
    assert_no_group_leakage(df["split"].values, df["group"].values)
    df.drop(columns=["hash"]).to_csv(cfg["paths"]["splits_csv"], index=False)

    n_groups = df["group"].nunique()
    dup_imgs = int((df.groupby("group")["group"].transform("size") > 1).sum())
    counts = df.pivot_table(index="label", columns="split", values="group", aggfunc="count", fill_value=0)
    res = cfg["paths"]["results_dir"]
    res.mkdir(parents=True, exist_ok=True)
    report = f"""# Data audit

| Item | Value |
|---|---|
| Images found | {len(rows)} |
| Images dropped (near-duplicates with conflicting labels) | {n_conflict_imgs} |
| Images kept | {len(df)} |
| Unique scans after near-duplicate grouping | {n_groups} |
| Images that have at least one near-duplicate | {dup_imgs} |
| Largest near-duplicate group (check if unexpectedly large) | {int(df.groupby("group").size().max())} |
| Original Kaggle *Testing* images with a near-duplicate in *Training* | {leaked} of {int(te_mask.sum())} |
| Median brain-mask fraction of frame | {df.brain_fraction.median():.2f} |

## Images per class and split (group-aware)

{counts.to_markdown()}
"""
    (res / "data_audit.md").write_text(report)
    print(report)


if __name__ == "__main__":
    main()
