"""Download PubMed abstracts for the retrieval corpus via NCBI E-utilities.

Only titles, abstracts and bibliographic metadata are stored. NCBI asks for
<= 3 requests/second without an API key; set NCBI_API_KEY to go faster and
NCBI_EMAIL to identify yourself (recommended by NCBI).

Usage:  python scripts/fetch_literature.py --per-query 150
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from brainrag.config import ROOT, load_config  # noqa: E402

EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
QUERIES = {
    "glioma": '(glioma[Title/Abstract]) AND (MRI[Title/Abstract]) AND (imaging features OR diagnosis)',
    "meningioma": '(meningioma[Title/Abstract]) AND (MRI[Title/Abstract]) AND (imaging features OR diagnosis)',
    "pituitary": '(pituitary adenoma[Title/Abstract] OR pituitary neuroendocrine tumor[Title/Abstract]) AND (MRI[Title/Abstract])',
    "notumor": '(normal brain MRI[Title/Abstract]) AND (incidental findings OR anatomy)',
    "ai": '(deep learning[Title/Abstract]) AND (brain tumor[Title/Abstract]) AND (MRI[Title/Abstract]) AND (classification OR explainability)',
}


def _get(url: str, params: dict) -> bytes:
    params = {**params, "tool": "brain-mri-rag"}
    if os.getenv("NCBI_EMAIL"):
        params["email"] = os.environ["NCBI_EMAIL"]
    if os.getenv("NCBI_API_KEY"):
        params["api_key"] = os.environ["NCBI_API_KEY"]
    with urllib.request.urlopen(f"{url}?{urllib.parse.urlencode(params)}", timeout=60) as r:
        data = r.read()
    time.sleep(0.12 if os.getenv("NCBI_API_KEY") else 0.4)
    return data


def search(term: str, n: int) -> list[str]:
    js = json.loads(_get(f"{EUTILS}/esearch.fcgi", {"db": "pubmed", "term": term, "retmax": n,
                                                     "retmode": "json", "sort": "relevance"}))
    return js["esearchresult"]["idlist"]


def fetch(pmids: list[str]) -> list[dict]:
    recs = []
    for i in range(0, len(pmids), 100):
        root = ET.fromstring(_get(f"{EUTILS}/efetch.fcgi", {"db": "pubmed", "id": ",".join(pmids[i:i + 100]),
                                                            "retmode": "xml"}))
        for art in root.findall(".//PubmedArticle"):
            abstract = " ".join("".join(t.itertext()) for t in art.findall(".//Abstract/AbstractText")).strip()
            if not abstract:
                continue
            recs.append({
                "pmid": art.findtext(".//PMID", ""),
                "title": "".join(art.find(".//ArticleTitle").itertext()) if art.find(".//ArticleTitle") is not None else "",
                "abstract": abstract,
                "journal": art.findtext(".//Journal/ISOAbbreviation", "") or art.findtext(".//Journal/Title", ""),
                "year": art.findtext(".//JournalIssue/PubDate/Year", "") or art.findtext(".//ArticleDate/Year", ""),
            })
    return recs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-query", type=int, default=150)
    args = ap.parse_args()
    out = load_config()["paths"]["literature_jsonl"]
    out.parent.mkdir(parents=True, exist_ok=True)
    seen, records = set(), []
    for topic, q in QUERIES.items():
        ids = [i for i in search(q, args.per_query) if i not in seen]
        seen.update(ids)
        recs = fetch(ids)
        for r in recs:
            r["topic"] = topic
        records += recs
        print(f"{topic}: {len(recs)} abstracts")
    with open(out, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"saved {len(records)} records to {out}")


if __name__ == "__main__":
    main()
