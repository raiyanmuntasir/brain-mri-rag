# Data

No data is stored in this repository. Download it yourself and accept each dataset's terms.

## 1. Brain Tumor MRI Dataset (required)

1. Create a free Kaggle account and open <https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset>.
2. Download and unzip it so the layout is:

```
data/raw/
├── Training/{glioma,meningioma,notumor,pituitary}/*.jpg
└── Testing/{glioma,meningioma,notumor,pituitary}/*.jpg
```

You can also use the Kaggle CLI:

```bash
pip install kaggle   # put kaggle.json in ~/.kaggle/
kaggle datasets download -d masoudnickparvar/brain-tumor-mri-dataset -p data/raw --unzip
```

The dataset's own Training/Testing folders are **not** used as the split. `scripts/prepare_data.py` pools all images, removes near-duplicate leakage and creates new group-aware splits. It records the original folder in `splits.csv` (`source_split`) so leakage in the original split can be measured.

## 2. BraTS (optional, for localisation metrics)

Register at <https://www.synapse.org/brats>. BraTS provides 3-D volumes with tumour masks. Extract axial slices and their masks to test Grad-CAM localisation (`cam_pointing_game`, `cam_iou` in `src/brainrag/metrics.py`).

## 3. PubMed abstracts (literature corpus)

`python scripts/fetch_literature.py` downloads titles and abstracts through NCBI E-utilities into `data/literature/pubmed.jsonl`. Set the `NCBI_EMAIL` environment variable, and optionally `NCBI_API_KEY`, as NCBI recommends.
