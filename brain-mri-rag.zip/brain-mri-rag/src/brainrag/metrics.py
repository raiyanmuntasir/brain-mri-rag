"""Classification, explainability and retrieval metrics (numpy / scikit-learn only)."""
from __future__ import annotations

import numpy as np
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, confusion_matrix,
                             f1_score, roc_auc_score)


def classification_metrics(y_true, probs, class_names):
    y_true = np.asarray(y_true)
    probs = np.asarray(probs)
    y_pred = probs.argmax(1)
    out = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro")),
        "macro_auc": float(roc_auc_score(y_true, probs, multi_class="ovr", average="macro")),
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=range(len(class_names))).tolist(),
        "per_class_f1": dict(zip(class_names, f1_score(y_true, y_pred, average=None,
                                                        labels=range(len(class_names))).tolist())),
    }
    return out


def bootstrap_ci(y_true, probs, metric: str = "macro_auc", n: int = 1000, seed: int = 0, alpha: float = 0.05):
    """Percentile bootstrap confidence interval for a metric on one test set."""
    rng = np.random.default_rng(seed)
    y_true = np.asarray(y_true)
    probs = np.asarray(probs)
    vals = []
    k = probs.shape[1]
    for _ in range(n):
        idx = rng.integers(0, len(y_true), len(y_true))
        if len(np.unique(y_true[idx])) < k:
            continue
        if metric == "macro_auc":
            vals.append(roc_auc_score(y_true[idx], probs[idx], multi_class="ovr", average="macro"))
        elif metric == "accuracy":
            vals.append(accuracy_score(y_true[idx], probs[idx].argmax(1)))
        elif metric == "macro_f1":
            vals.append(f1_score(y_true[idx], probs[idx].argmax(1), average="macro"))
        else:
            raise ValueError(metric)
    lo, hi = np.percentile(vals, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return float(lo), float(hi)


def cam_in_brain_ratio(cam: np.ndarray, brain: np.ndarray) -> float:
    """Share of Grad-CAM energy that falls inside the brain mask (1.0 = all inside).

    Directly measures the failure seen in the original paper, where heat maps
    concentrated on the orbits and nasal cavity.
    """
    cam = np.clip(cam.astype(np.float64), 0, None)
    total = cam.sum()
    if total <= 0:
        return float("nan")
    return float(cam[brain.astype(bool)].sum() / total)


def cam_pointing_game(cam: np.ndarray, lesion: np.ndarray) -> bool:
    """True if the CAM maximum lies inside the lesion mask (needs BraTS-style masks)."""
    y, x = np.unravel_index(int(np.argmax(cam)), cam.shape)
    return bool(lesion[y, x])


def cam_iou(cam: np.ndarray, lesion: np.ndarray, quantile: float = 0.9) -> float:
    thr = np.quantile(cam, quantile)
    pred = (cam >= thr) & (cam > 0)
    les = lesion.astype(bool)
    union = (pred | les).sum()
    return float((pred & les).sum() / union) if union else float("nan")


def precision_at_k(query_labels, neighbor_labels) -> float:
    """Mean fraction of retrieved neighbours that share the query label."""
    q = np.asarray(query_labels)[:, None]
    nb = np.asarray(neighbor_labels)
    return float((nb == q).mean())


def mean_std(values):
    v = np.asarray(values, dtype=float)
    return float(v.mean()), float(v.std(ddof=1)) if len(v) > 1 else 0.0
