import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from brainrag.dedup import dhash, duplicate_groups, embedding_duplicate_groups, label_conflicts  # noqa: E402
from brainrag.splits import assert_no_group_leakage, group_split  # noqa: E402


def _img(seed):
    rng = np.random.default_rng(seed)
    base = rng.integers(0, 255, (16, 16)).astype(np.uint8)
    return np.kron(base, np.ones((16, 16), np.uint8))  # 256x256 blocky image


def test_near_duplicates_grouped_distinct_separated():
    a = _img(1)
    a_noisy = np.clip(a.astype(int) + np.random.default_rng(9).integers(-3, 4, a.shape), 0, 255).astype(np.uint8)
    b = _img(2)
    g = duplicate_groups([dhash(a), dhash(a_noisy), dhash(b)], max_distance=4)
    assert g[0] == g[1] and g[0] != g[2]


def test_embedding_groups():
    e = np.array([[1, 0, 0], [0.999, 0.01, 0], [0, 1, 0]], np.float32)
    g = embedding_duplicate_groups(e, 0.98)
    assert g[0] == g[1] != g[2]


def test_label_conflicts():
    assert label_conflicts(np.array([0, 0, 1]), ["glioma", "pituitary", "glioma"]) == [0]


def test_group_split_no_leakage_and_all_classes():
    rng = np.random.default_rng(0)
    n = 800
    groups = rng.integers(0, 300, n)                 # many duplicate groups
    labels = np.array(["glioma", "meningioma", "notumor", "pituitary"])[groups % 4]
    split = group_split(labels, groups, 0.15, 0.15, seed=1)
    assert_no_group_leakage(split, groups)
    for s in ("train", "val", "test"):
        assert set(labels[split == s]) == {"glioma", "meningioma", "notumor", "pituitary"}
    frac_test = (split == "test").mean()
    assert 0.08 < frac_test < 0.25
