import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from brainrag.preprocessing import PreprocessConfig, brain_mask, clahe, preprocess  # noqa: E402


def phantom(size=256, seed=0):
    """Synthetic head: bright skull ring, mid-grey brain with a bright 'tumour',
    and two bright 'eyes' outside the skull (the shortcut the original model learned)."""
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[:size, :size]
    c = size / 2
    r = np.hypot(yy - c, xx - c)
    img = np.zeros((size, size), np.float32)
    img[(r > 92) & (r < 100)] = 230                     # skull
    brain = r < 84
    img[brain] = 120                                    # brain
    img[np.hypot(yy - 110, xx - 150) < 14] = 200        # tumour
    for ex in (95, 161):                                # eyes, outside the skull
        img[np.hypot(yy - 22, xx - ex) < 10] = 210
    img += rng.normal(0, 4, img.shape)
    return np.clip(img, 0, 255).astype(np.uint8), brain


def test_mask_covers_brain_and_excludes_eyes():
    img, brain = phantom()
    m = brain_mask(img, erode_px=2)
    inside = (m & brain).sum() / brain.sum()
    assert inside > 0.9, inside
    yy, xx = np.mgrid[:256, :256]
    eyes = (np.hypot(yy - 22, xx - 95) < 10) | (np.hypot(yy - 22, xx - 161) < 10)
    assert (m & eyes).sum() == 0


def test_preprocess_shapes_and_background():
    img, _ = phantom()
    out, mask = preprocess(img, PreprocessConfig(size=224))
    assert out.shape == (224, 224) and mask.shape == (224, 224)
    assert out.dtype == np.uint8 and mask.dtype == bool
    assert out[~mask].max() == 0          # everything outside the brain is zeroed
    assert out[mask].std() > 0


def test_clahe_keeps_range():
    img, _ = phantom()
    out = clahe(img)
    assert out.dtype == np.uint8 and out.shape == img.shape


def test_blank_image_does_not_crash():
    out, mask = preprocess(np.zeros((128, 128), np.uint8))
    assert out.shape == (224, 224)
