"""Vector indices for (a) similar-case image retrieval and (b) literature retrieval.

FAISS is used when installed; otherwise an exact numpy implementation with the
same interface is used, so everything works on a laptop without extra installs.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

try:  # optional
    import faiss  # type: ignore
except ImportError:  # pragma: no cover
    faiss = None


def l2_normalize(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    return x / (np.linalg.norm(x, axis=1, keepdims=True) + 1e-12)


class VectorIndex:
    """Cosine-similarity index with metadata."""

    def __init__(self, dim: int, use_faiss: bool = True):
        self.dim = dim
        self.meta: list[dict] = []
        self._use_faiss = bool(use_faiss and faiss is not None)
        self._faiss = faiss.IndexFlatIP(dim) if self._use_faiss else None
        self._mat = np.zeros((0, dim), dtype=np.float32)

    def __len__(self):
        return len(self.meta)

    def add(self, vectors: np.ndarray, meta: list[dict]) -> None:
        v = l2_normalize(vectors)
        if v.shape[1] != self.dim:
            raise ValueError(f"expected dim {self.dim}, got {v.shape[1]}")
        if len(meta) != len(v):
            raise ValueError("vectors and metadata length differ")
        if self._use_faiss:
            self._faiss.add(v)
        else:
            self._mat = np.vstack([self._mat, v])
        self.meta.extend(meta)

    def search(self, queries: np.ndarray, k: int = 5):
        q = l2_normalize(np.atleast_2d(queries))
        k = min(k, len(self.meta))
        if self._use_faiss:
            sims, idx = self._faiss.search(q, k)
        else:
            s = q @ self._mat.T
            idx = np.argsort(-s, axis=1)[:, :k]
            sims = np.take_along_axis(s, idx, axis=1)
        results = []
        for row_s, row_i in zip(sims, idx):
            results.append([{**self.meta[i], "score": float(sc)} for sc, i in zip(row_s, row_i)])
        return results

    # ---- persistence -------------------------------------------------
    def save(self, directory: str | Path) -> None:
        d = Path(directory)
        d.mkdir(parents=True, exist_ok=True)
        mat = self._mat if not self._use_faiss else self._faiss.reconstruct_n(0, len(self.meta))
        np.save(d / "vectors.npy", mat)
        (d / "meta.json").write_text(json.dumps(self.meta))

    @classmethod
    def load(cls, directory: str | Path, use_faiss: bool = True) -> "VectorIndex":
        d = Path(directory)
        mat = np.load(d / "vectors.npy")
        meta = json.loads((d / "meta.json").read_text())
        idx = cls(mat.shape[1], use_faiss=use_faiss)
        if len(meta):
            idx.add(mat, meta)
        return idx


# ---------------------------------------------------------------------
# Literature corpus
# ---------------------------------------------------------------------
@dataclass
class Passage:
    text: str
    pmid: str
    title: str
    year: str = ""
    journal: str = ""
    extra: dict = field(default_factory=dict)


def chunk_abstract(record: dict, sentences_per_chunk: int = 3) -> list[Passage]:
    """Split an abstract into overlapping sentence windows."""
    sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+", record.get("abstract", "")) if s.strip()]
    if not sents:
        return []
    step = max(1, sentences_per_chunk - 1)
    out = []
    for i in range(0, len(sents), step):
        window = " ".join(sents[i:i + sentences_per_chunk])
        out.append(Passage(text=window, pmid=str(record.get("pmid", "")), title=record.get("title", ""),
                           year=str(record.get("year", "")), journal=record.get("journal", "")))
        if i + sentences_per_chunk >= len(sents):
            break
    return out


class TextEmbedder:
    """Biomedical sentence embeddings, with a TF-IDF fallback.

    Default model: ``pritamdeka/S-PubMedBert-MS-MARCO`` (PubMedBERT fine-tuned for
    retrieval). If sentence-transformers is unavailable, falls back to TF-IDF
    so the pipeline still runs (with weaker retrieval quality).
    """

    def __init__(self, model_name: str = "pritamdeka/S-PubMedBert-MS-MARCO", force_tfidf: bool = False):
        self.model_name = model_name
        self._st = None
        self._tfidf = None
        if not force_tfidf:
            try:
                from sentence_transformers import SentenceTransformer
                self._st = SentenceTransformer(model_name)
            except Exception:  # pragma: no cover - optional dependency / offline
                self._st = None
        self.backend = "sentence-transformers" if self._st is not None else "tfidf"

    def fit(self, corpus: list[str]) -> "TextEmbedder":
        if self._st is None:
            from sklearn.feature_extraction.text import TfidfVectorizer
            self._tfidf = TfidfVectorizer(ngram_range=(1, 2), min_df=1, sublinear_tf=True,
                                          stop_words="english").fit(corpus)
        return self

    def encode(self, texts: list[str]) -> np.ndarray:
        if self._st is not None:
            return np.asarray(self._st.encode(texts, normalize_embeddings=True), dtype=np.float32)
        if self._tfidf is None:
            raise RuntimeError("call fit() before encode() when using the TF-IDF backend")
        return self._tfidf.transform(texts).toarray().astype(np.float32)


def load_jsonl(path: str | Path) -> list[dict]:
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]
