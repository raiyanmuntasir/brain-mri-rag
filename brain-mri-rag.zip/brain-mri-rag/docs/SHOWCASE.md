# How to present this project

Fill every `[bracket]` with numbers produced by your own runs (`results/summary.md`, `results/data_audit.md`). Never quote a number you have not reproduced.

---

## One-line description (GitHub "About" box)

> Explainable brain-tumour MRI classifier with leakage-free evaluation, similar-case retrieval and citation-grounded LLM summaries (research prototype).

**Topics to add on GitHub:** `medical-imaging` `deep-learning` `vision-transformer` `explainable-ai` `grad-cam` `retrieval-augmented-generation` `rag` `faiss` `pytorch` `healthcare-ai` `mri`

---

## Resume / CV entry

**Retrieval-Augmented Brain MRI Assistant** | Python, PyTorch, FAISS, PubMedBERT, Ollama | [GitHub link] | [Year]
- Built an explainable 4-class brain-tumour MRI classifier (hybrid CNN–Vision Transformer with cross-attention fusion), achieving [macro-AUC ± SD] over 5 seeds on a de-duplicated, group-aware test split.
- Found that [N] of [M] images in the public dataset's test folder had near-duplicates in its training folder. Designed a perceptual-hash de-duplication and group-split pipeline to remove this leakage.
- Added anatomy-aware preprocessing (brain masking, CLAHE) that raised the share of Grad-CAM attention inside the brain from [x] to [y].
- Implemented retrieval-augmented reporting: FAISS similar-case retrieval (precision@5 = [value]) and PubMedBERT literature retrieval, with a local LLM and an automatic citation validator that blocks fabricated references.

Use the "raised from [x] to [y]" bullet only if you actually run the ablation: train once with `preprocess` disabled and once enabled.

---

## LinkedIn / portfolio post (≈150 words)

> Many published brain-tumour MRI classifiers report 95%+ accuracy on a popular public dataset. When I re-examined my own earlier work, I found two problems: near-duplicate images shared between the training and test sets, and heat maps showing the model looking at the eyes instead of the brain.
>
> So I rebuilt the pipeline from scratch, open-source:
> • de-duplication + group-aware splits ([N] leaked test images found)
> • brain masking so the model can only learn from brain tissue
> • a hybrid CNN–ViT benchmarked against 3 baselines over 5 seeds
> • retrieval of similar reference cases and PubMed evidence, summarised by a local LLM that must cite every claim, with automatic rejection of made-up references
>
> Honest numbers: [macro-AUC ± SD]. Lower than the leaderboard, and more trustworthy.
>
> Code: [link]. Research prototype only, not for clinical use.
> #MedicalAI #MachineLearning #ExplainableAI #RAG

---

## Interview talking points

1. **Why de-duplicate?** Duplicates across splits test memorisation, not generalisation. Group-aware splitting is standard practice in medical ML, where patients contribute multiple images.
2. **Why measure the in-brain ratio?** Shortcut learning (scanner text, borders, anatomy outside the region of interest) is a documented failure mode in medical imaging. Turning a qualitative heat map into a number makes it testable across models.
3. **Why doesn't the LLM see the image?** Grounding. It can only restate verifiable evidence, which is why every citation can be validated, and why a deterministic fallback exists when validation fails.
4. **Why a local LLM?** Privacy. Credentialed clinical datasets (e.g. MIMIC) forbid sending data to third-party APIs, and the same design applies to hospital deployment.
5. **What would you do next?** External validation on BraTS, patient-level splits with 3-D volumes, calibration (ECE) and radiologist evaluation of the summaries.

---

## Turning it into a paper

The project is structured so the results can support a short paper, for example:
*"Data leakage and shortcut learning in public brain-tumour MRI benchmarks: a retrieval-augmented, explainable re-evaluation."*

Candidate venues include *BMC Medical Imaging*, *Scientific Reports* and *PLOS ONE*, and MICCAI or MIDL workshops. Before submitting:
- Run all 4 models × 5 seeds.
- Add the preprocessing ablation and BraTS localisation.
- Post a preprint (arXiv or medRxiv).
- Archive the exact code version on Zenodo to get a DOI.

---

## Making the repository count as evidence

- Archive a release on **Zenodo** (GitHub → Zenodo integration) to get a citable DOI.
- Pin the repository on your GitHub profile and link it from your resume, LinkedIn and Google Scholar.
- Keep commit history genuine and dated. Do not back-date or describe this code as the code of earlier publications.
- Third-party use (stars from strangers, forks, issues, citations) is what demonstrates impact. Share it in relevant communities and respond to issues.
